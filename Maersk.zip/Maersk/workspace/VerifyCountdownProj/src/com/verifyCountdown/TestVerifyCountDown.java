package com.verifyCountdown;

import java.io.FileInputStream;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.Assert;
import org.testng.annotations.Test;

public class TestVerifyCountDown {
	
	static WebDriver driver=null;
	static WebElement inputText = null;
	static String startTime = null; 
	static String endTime = null;
	static int counter = 25;
	
	static Properties prop = new Properties();
	
	static FileInputStream input = null;
	
  @Test(priority=1)
  public static void launchBrowser() {
		
	  
		try {
			
		input = new FileInputStream("src\\com\\verifyCountDown\\objRepo.properties");
		prop.load(input);
			
		System.setProperty(prop.getProperty("DriverName"), prop.getProperty("DriverPath"));
		driver=new FirefoxDriver();
		driver.get(prop.getProperty("URL"));

		Thread.sleep(5000);
		
		driver.manage().window().maximize();
		
		}catch(Exception e) {
			System.out.println("Failure to launch the browser."+ e);
		}
	}
  
  @Test(priority=2)
  public static void verifyCountDown() {
	  
		
		try {
		
			
		input = new FileInputStream("src\\com\\verifyCountDown\\objRepo.properties");
		prop.load(input);
			
		Thread.sleep(2000);
		
		inputText=driver.findElement(By.xpath(prop.getProperty("textBoxXpath")));
		inputText.sendKeys(prop.getProperty("inputValue"));
		
		driver.findElement(By.xpath(prop.getProperty("startButtonXpath"))).click();
		
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
		while(counter>=0) {
			startTime = driver.findElement(By.xpath(prop.getProperty("timerXpath"))).getText();
			if(startTime.equals("0 second")) {
				System.out.println("startTime==>"+startTime);
				Thread.sleep(2000);
				driver.switchTo().alert().accept();
				Thread.sleep(2000);
				String timeExpired = driver.findElement(By.xpath(prop.getProperty("timerXpath"))).getText();
				Assert.assertEquals(prop.getProperty("ActualText"), timeExpired, "Text Verified.");
				break;
				
			} else {
					System.out.println("startTime else==>"+startTime);
					endTime=startTime;
					Assert.assertEquals(startTime, endTime, "Text Verified.");
				
			}
			counter++;
		}
		}catch(Exception e) {
			System.out.println("Interrupted Exception==>" + e);
		}
	}
  
	@Test(priority=3)
	public void closeBrowser() {
		try {
			driver.close();
		}catch(Exception e) {
			System.out.println("Failure to close the browser."+ e);
		}
			
	}
}
